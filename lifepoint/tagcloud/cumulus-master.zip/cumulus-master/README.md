Cumulus
=======

Work-in-progress version 2.0 of the Flash movie that powered WP-Cumulus.

Please note that this is not a drop-in replacement for the Flash movie
used in the now-discontinued WordPress plugin. It was created to be more
generic, and no longer uses an XML format that resembles WordPress's tag
cloud html.

Please feel free to write a new plugin wrapper for WordPress or any
other platform, or to convert this into HTML5/Canvas or any other
suitable technology.
