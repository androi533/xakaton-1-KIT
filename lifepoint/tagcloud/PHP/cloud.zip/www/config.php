<?php

    define ("IRB_WIDTH", 200);              //Ширина облака
    define ("IRB_HEIGHT", 150);             //Высота
    define ("IRB_VERSION_FLASH", 9);       //Версия FLASH-плеера
    define ("IRB_BACKGROUND", "#ffffff");   //Фон облака
    define ("IRB_T_COLOR", "0x19b509");     //Цвет тектса
    define ("IRB_T_SPEED", "200");          //Скорость вращения
    define ("IRB_DISTR", "true");           //Вид облака, если FALSE, облако примет иной вид
    define ("IRB_MODE", "tags");            //
    define ("IRB_TAGS", "tags");            //ID DIV'а